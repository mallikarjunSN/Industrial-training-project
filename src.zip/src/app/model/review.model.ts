export interface Review{
    rating:Number;
    comments:String;
}